import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { products } from './catalog';

export type CartLine = { productId: string; quantity: number };

type StoreValue = {
  cart: CartLine[];
  addToCart: (id: string, quantity?: number) => void;
  setQuantity: (id: string, quantity: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  cartCount: number;
};

const CART_KEY = 'shopease-cart-v1';
const StoreContext = createContext<StoreValue | null>(null);

function readCart(): CartLine[] {
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(CART_KEY) ?? '[]');
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is CartLine => {
      return typeof item?.productId === 'string'
        && products.some((product) => product.id === item.productId)
        && Number.isInteger(item.quantity)
        && item.quantity > 0;
    }).map((item) => {
      const product = products.find((candidate) => candidate.id === item.productId)!;
      return { productId: item.productId, quantity: Math.min(item.quantity, product.stock) };
    });
  } catch {
    return [];
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartLine[]>(readCart);

  useEffect(() => {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch {
      // local storage may be unavailable
    }
  }, [cart]);

  const addToCart = (id: string, quantity = 1) => {
    const product = products.find((item) => item.id === id);
    if (!product || product.stock < 1) return;
    setCart((current) => {
      const exists = current.find((item) => item.productId === id);
      if (exists) {
        return current.map((item) => item.productId === id
          ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
          : item);
      }
      return [...current, { productId: id, quantity: Math.min(product.stock, quantity) }];
    });
  };

  const setQuantity = (id: string, quantity: number) => {
    const product = products.find((item) => item.id === id);
    if (!product) return;
    setCart((current) => current.map((line) => line.productId === id
      ? { ...line, quantity: Math.max(1, Math.min(product.stock, quantity)) }
      : line));
  };

  const removeFromCart = (id: string) => setCart((current) => current.filter((item) => item.productId !== id));
  const clearCart = () => setCart([]);
  const cartCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);
  const value = useMemo(
    () => ({ cart, addToCart, setQuantity, removeFromCart, clearCart, cartCount }),
    [cart, cartCount],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error('Store components must be used inside StoreProvider');
  return context;
}
