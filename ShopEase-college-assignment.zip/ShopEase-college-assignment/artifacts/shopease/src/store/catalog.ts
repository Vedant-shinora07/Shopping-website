export type Category = 'Electronics' | 'Furniture' | 'Stationery';

export type Product = {
  id: string;
  name: string;
  category: Category;
  price: number;
  stock: number;
  image: string;
  description: string;
  color: string;
};

function productArtwork(id: string, bg: string, accent: string): string {
  const shape: Record<string, string> = {
    laptop: '<rect x="29" y="33" width="142" height="96" rx="9" fill="#5F746C"/><rect x="38" y="42" width="124" height="76" rx="4" fill="#B6D1C3"/><path d="M19 137h162l-13 13H31l-12-13Z" fill="#89978F"/><path d="M75 139h50" stroke="#D9E3DD" stroke-width="3" stroke-linecap="round"/>',
    mouse: '<path d="M100 30c-34 0-54 25-54 65v17c0 31 21 51 54 51s54-20 54-51V95c0-40-20-65-54-65Z" fill="#748A80"/><path d="M100 31v48" stroke="#C7D7CE" stroke-width="4"/><path d="M100 78h49" stroke="#C7D7CE" stroke-width="3"/>',
    keyboard: '<rect x="22" y="56" width="156" height="85" rx="12" fill="#657A72"/><g fill="#D7E1D9"><path d="M35 69h17v13H35zm23 0h17v13H58zm23 0h17v13H81zm23 0h17v13h-17zm23 0h17v13h-17zm23 0h17v13h-17zM35 89h17v13H35zm23 0h17v13H58zm23 0h17v13H81zm23 0h17v13h-17zm23 0h17v13h-17zm23 0h17v13h-17zM35 109h17v13H35zm23 0h17v13H58zm23 0h17v13H81zm23 0h17v13h-17zm23 0h40v13h-40z"/></g>',
    headphones: '<path d="M44 103V85c0-33 25-59 56-59s56 26 56 59v18" fill="none" stroke="#687F75" stroke-width="17" stroke-linecap="round"/><rect x="31" y="91" width="34" height="65" rx="15" fill="#C77D60"/><rect x="135" y="91" width="34" height="65" rx="15" fill="#C77D60"/><path d="M49 103v39m102-39v39" stroke="#F0C4A5" stroke-width="5" stroke-linecap="round"/>',
    chair: '<path d="M62 46q0-10 10-10h54q10 0 10 10v60H62V46Z" fill="#C98568"/><rect x="49" y="101" width="100" height="22" rx="8" fill="#D99979"/><path d="M70 122v30m59-30v30m-30-1-25 13m25-13 26 13" stroke="#647B70" stroke-width="8" stroke-linecap="round"/>',
    table: '<path d="M25 61q0-9 10-9h130q10 0 10 9v21H25V61Z" fill="#C98D66"/><path d="M42 82h116l-12 71H54L42 82Z" fill="#B77A57"/><path d="M57 93h85" stroke="#DCAA83" stroke-width="4" stroke-linecap="round"/>',
    notebook: '<rect x="52" y="28" width="104" height="137" rx="9" fill="#D8A94E"/><rect x="61" y="28" width="93" height="137" rx="8" fill="#F1D988"/><path d="M78 63h57m-57 20h57m-57 20h57m-57 20h43" stroke="#B79645" stroke-width="4" stroke-linecap="round"/><path d="M54 39h8m-8 18h8m-8 18h8m-8 18h8m-8 18h8m-8 18h8m-8 18h8" stroke="#B98547" stroke-width="4"/>',
    pen: '<path d="m75 148 17-6 54-93-20-12-54 92 3 19Z" fill="#668875"/><path d="m126 37 20 12 8-13-20-12-8 13Z" fill="#D5A34E"/><path d="m73 151 19-9-16-10-3 19Z" fill="#53695D"/><path d="m89 137 53-91" stroke="#A8C4AF" stroke-width="3"/>',
  };
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="190" viewBox="0 0 200 190"><rect width="200" height="190" rx="28" fill="${bg}"/><circle cx="157" cy="39" r="18" fill="${accent}" opacity=".35"/><ellipse cx="100" cy="157" rx="73" ry="9" fill="#45574D" opacity=".11"/>${shape[id]}</svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

export const products: Product[] = [
  {
    id: 'laptop',
    name: 'Laptop',
    category: 'Electronics',
    price: 55000,
    stock: 8,
    image: productArtwork('laptop', '#E8EFE8', '#E5B18C'),
    description: 'A dependable everyday laptop for lectures, research and late-night project sessions. Lightweight enough to take from class to the library.',
    color: '#E8EFE8',
  },
  {
    id: 'mouse',
    name: 'Mouse',
    category: 'Electronics',
    price: 800,
    stock: 24,
    image: productArtwork('mouse', '#F4E8DB', '#C77D60'),
    description: 'A comfortable, precise wired mouse that keeps your desk setup simple and your work moving smoothly.',
    color: '#F4E8DB',
  },
  {
    id: 'keyboard',
    name: 'Keyboard',
    category: 'Electronics',
    price: 1500,
    stock: 17,
    image: productArtwork('keyboard', '#E8EBE4', '#93A98D'),
    description: 'A reliable full-size keyboard with a satisfying, quiet feel for notes, code and everything in between.',
    color: '#E8EBE4',
  },
  {
    id: 'headphones',
    name: 'Headphones',
    category: 'Electronics',
    price: 2000,
    stock: 12,
    image: productArtwork('headphones', '#F2E7DF', '#D38B6A'),
    description: 'Soft over-ear headphones for focused study, recorded lectures and a little quiet between classes.',
    color: '#F2E7DF',
  },
  {
    id: 'chair',
    name: 'Chair',
    category: 'Furniture',
    price: 4500,
    stock: 6,
    image: productArtwork('chair', '#F2E5DD', '#D99D7E'),
    description: 'A supportive, compact desk chair designed to make long study sessions feel a little more comfortable.',
    color: '#F2E5DD',
  },
  {
    id: 'table',
    name: 'Table',
    category: 'Furniture',
    price: 7000,
    stock: 5,
    image: productArtwork('table', '#EAEDE4', '#849983'),
    description: 'A sturdy, uncluttered work surface with room for your books, laptop and the plans for what comes next.',
    color: '#EAEDE4',
  },
  {
    id: 'notebook',
    name: 'Notebook',
    category: 'Stationery',
    price: 100,
    stock: 60,
    image: productArtwork('notebook', '#F7F0D9', '#D4A74C'),
    description: 'A slim, ruled notebook ready for lecture notes, quick sketches and ideas worth keeping.',
    color: '#F7F0D9',
  },
  {
    id: 'pen',
    name: 'Pen',
    category: 'Stationery',
    price: 20,
    stock: 120,
    image: productArtwork('pen', '#E6EEE5', '#C5D6C4'),
    description: 'A smooth everyday writing pen that belongs in every backpack, pencil case and desk drawer.',
    color: '#E6EEE5',
  },
];

export const formatRupees = (amount: number) =>
  `₹${amount.toLocaleString('en-IN')}`;
