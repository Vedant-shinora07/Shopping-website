import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { formatRupees, type Product } from '../store/catalog';
import { useStore } from '../store/StoreContext';

export function CartItem({ product, quantity }: { product: Product; quantity: number }) {
  const { setQuantity, removeFromCart } = useStore();
  return (
    <article className="cart-row" data-testid={`row-cart-${product.id}`}>
      <Link to={`/products/${product.id}`} className="cart-thumb">
        <img src={product.image} alt={product.name} />
      </Link>
      <div>
        <Link to={`/products/${product.id}`} className="cart-name">{product.name}</Link>
        <div className="cart-category">{product.category} · {formatRupees(product.price)} each</div>
        <div className="cart-line-price">{formatRupees(product.price * quantity)}</div>
      </div>
      <div className="cart-controls">
        <div className="qty-control" aria-label={`Quantity for ${product.name}`}>
          <button
            aria-label={`Decrease ${product.name} quantity`}
            onClick={() => setQuantity(product.id, quantity - 1)}
            disabled={quantity <= 1}
            data-testid={`button-qty-minus-${product.id}`}
          ><Minus size={14} /></button>
          <span data-testid={`text-qty-${product.id}`}>{quantity}</span>
          <button
            aria-label={`Increase ${product.name} quantity`}
            onClick={() => setQuantity(product.id, quantity + 1)}
            disabled={quantity >= product.stock}
            data-testid={`button-qty-plus-${product.id}`}
          ><Plus size={14} /></button>
        </div>
        <button
          className="remove-button"
          aria-label={`Remove ${product.name}`}
          title="Remove item"
          onClick={() => removeFromCart(product.id)}
          data-testid={`button-remove-${product.id}`}
        ><Trash2 size={16} /></button>
      </div>
    </article>
  );
}
