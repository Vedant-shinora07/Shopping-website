import { Search } from 'lucide-react';
import type { Product } from '../store/catalog';
import { ProductCard } from './ProductCard';

export function ProductGrid({ items }: { items: Product[] }) {
  if (items.length === 0) {
    return (
      <div className="empty-state">
        <div className="empty-icon"><Search size={27} /></div>
        <h2>No study essentials found</h2>
        <p>Try another name or choose a different category.</p>
      </div>
    );
  }

  return <div className="product-grid">{items.map((product) => <ProductCard key={product.id} product={product} />)}</div>;
}
