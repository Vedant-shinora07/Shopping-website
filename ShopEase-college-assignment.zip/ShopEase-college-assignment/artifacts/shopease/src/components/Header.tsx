import { Link, NavLink } from 'react-router-dom';
import { ShoppingBag, ShoppingCart } from 'lucide-react';
import { useStore } from '../store/StoreContext';

export function Header() {
  const { cartCount } = useStore();
  return (
    <header className="topbar">
      <div className="page-shell nav-inner">
        <Link to="/" className="brand" aria-label="ShopEase home" data-testid="link-brand">
          <span className="brand-mark"><ShoppingBag size={19} strokeWidth={2.5} /></span>
          <span>ShopEase</span>
        </Link>
        <nav className="nav-links" aria-label="Main navigation">
          <NavLink to="/" end data-testid="link-home">Home</NavLink>
          <NavLink to="/products" data-testid="link-products">Products</NavLink>
        </nav>
        <Link to="/cart" className="cart-link" data-testid="link-cart">
          <ShoppingCart size={17} />
          <span className="cart-link-label">Your cart</span>
          <span className="count-pill" data-testid="text-cart-count">{cartCount}</span>
        </Link>
      </div>
    </header>
  );
}
