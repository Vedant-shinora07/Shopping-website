import { useState, type CSSProperties } from 'react';
import { Link } from 'react-router-dom';
import { Check, Plus } from 'lucide-react';
import { formatRupees, type Product } from '../store/catalog';
import { useStore } from '../store/StoreContext';

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useStore();
  const [added, setAdded] = useState(false);
  const handleAdd = () => {
    addToCart(product.id);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1500);
  };

  return (
    <article className="product-card" data-testid={`card-product-${product.id}`}>
      <Link
        to={`/products/${product.id}`}
        className="product-visual"
        style={{ '--art-bg': product.color } as CSSProperties}
        data-testid={`link-product-${product.id}`}
      >
        <span className="category-tag">{product.category}</span>
        <img src={product.image} alt={product.name} />
      </Link>
      <div className="product-info">
        <Link to={`/products/${product.id}`}><h3>{product.name}</h3></Link>
        <p>{product.description}</p>
        <div className="product-bottom">
          <div>
            <div className="price" data-testid={`text-price-${product.id}`}>{formatRupees(product.price)}</div>
            <div className="stock">{product.stock} in stock</div>
          </div>
          <button
            className="icon-button"
            onClick={handleAdd}
            aria-label={`Add ${product.name} to cart`}
            title={added ? 'Added to cart' : 'Add to cart'}
            data-testid={`button-add-${product.id}`}
          >
            {added ? <Check size={17} /> : <Plus size={18} />}
          </button>
        </div>
      </div>
    </article>
  );
}
