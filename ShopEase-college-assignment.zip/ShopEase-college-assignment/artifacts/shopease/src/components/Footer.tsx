export function Footer() {
  return (
    <footer className="footer">
      <div className="page-shell footer-inner">
        <div><strong>ShopEase</strong> <span>· The little campus shop for big study days.</span></div>
        <span>Thoughtfully picked for campus life.</span>
      </div>
    </footer>
  );
}
