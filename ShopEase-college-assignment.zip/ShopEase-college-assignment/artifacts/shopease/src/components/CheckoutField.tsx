import type { ReactElement, ReactNode } from 'react';

export function CheckoutField({
  label,
  error,
  className,
  children,
}: {
  label: string;
  error?: string;
  className?: string;
  children: ReactNode;
}) {
  const inputId = (children as ReactElement<{ id?: string }>).props.id;
  return (
    <div className={`field ${className ?? ''}`}>
      <label htmlFor={inputId}>{label}</label>
      {children}
      {error && <span className="field-error" role="alert">{error}</span>}
    </div>
  );
}
