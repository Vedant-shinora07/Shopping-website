import type { ReactNode } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { formatRupees } from '../store/catalog';

export function OrderSummary({ subtotal, itemCount, cta }: { subtotal: number; itemCount: number; cta: ReactNode }) {
  return (
    <aside className="summary-card" aria-label="Order summary">
      <h2>Order summary</h2>
      <div className="summary-line"><span>Items ({itemCount})</span><span>{formatRupees(subtotal)}</span></div>
      <div className="summary-line"><span>Campus delivery</span><span style={{ color: 'hsl(var(--primary))', fontWeight: 700 }}>On us</span></div>
      <div className="summary-total"><span>Total</span><span>{formatRupees(subtotal)}</span></div>
      {cta}
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: '#85918a', fontSize: 11, justifyContent: 'center', marginTop: 13 }}>
        <CheckCircle2 size={14} /> Demo checkout, no payment taken
      </div>
    </aside>
  );
}
