import { Link } from 'react-router-dom';

export function NotFoundPage() {
  return (
    <div className="not-found">
      <div>
        <div className="eyebrow">Wrong turn</div>
        <h1>We can't find that page.</h1>
        <p style={{ color: '#7b8780', margin: '10px 0 22px' }}>Let's get you back to the useful things.</p>
        <Link to="/" className="button">Back home</Link>
      </div>
    </div>
  );
}
