import { useMemo, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, CheckCircle2, ChevronRight, ShoppingBag } from 'lucide-react';
import { formatRupees, products } from '../store/catalog';
import { CheckoutField } from '../components/CheckoutField';
import { useStore } from '../store/StoreContext';

type Customer = { name: string; email: string; mobile: string; address: string };
const initialCustomer: Customer = { name: '', email: '', mobile: '', address: '' };

export function CheckoutPage() {
  const { cart, clearCart } = useStore();
  const [customer, setCustomer] = useState<Customer>(initialCustomer);
  const [errors, setErrors] = useState<Partial<Customer>>({});
  const [completed, setCompleted] = useState(false);
  const [orderId, setOrderId] = useState('');
  const lines = useMemo(() => cart.map((line) => ({
    ...line,
    product: products.find((product) => product.id === line.productId)!,
  })).filter((line) => line.product), [cart]);
  const subtotal = useMemo(() => lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0), [lines]);

  if (completed) {
    return (
      <section className="success-card">
        <div className="success-mark"><Check size={29} /></div>
        <div className="eyebrow">All sorted</div>
        <h1>Thanks, {customer.name.split(' ')[0]}.</h1>
        <p>Your demo order has been placed. We've saved your delivery details for this confirmation — no payment was collected.</p>
        <div className="order-ref">Order reference · {orderId}</div>
        <div><Link to="/products" className="button">Back to the shop <ArrowRight size={16} /></Link></div>
      </section>
    );
  }

  if (lines.length === 0) {
    return (
      <>
        <div className="page-title"><div className="eyebrow">Almost there</div><h1>Checkout</h1></div>
        <div className="empty-state" style={{ margin: '12px 0 75px' }}>
          <div className="empty-icon"><ShoppingBag size={26} /></div>
          <h2>Your cart is waiting for a pick</h2>
          <p>Add something useful and it will be ready for checkout here.</p>
          <Link to="/products" className="button">Explore products</Link>
        </div>
      </>
    );
  }

  const update = (key: keyof Customer, value: string) => {
    setCustomer((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors: Partial<Customer> = {};
    if (customer.name.trim().length < 2) nextErrors.name = 'Please enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email.trim())) nextErrors.email = 'Enter a valid email address.';
    if (!/^[6-9]\d{9}$/.test(customer.mobile.replace(/\D/g, ''))) nextErrors.mobile = 'Enter a valid 10-digit Indian mobile number.';
    if (customer.address.trim().length < 10) nextErrors.address = 'Add a complete delivery address (at least 10 characters).';
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;
    setOrderId(`SE-${Math.floor(100000 + Math.random() * 899999)}`);
    clearCart();
    setCompleted(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <div className="page-title">
        <div className="breadcrumb"><Link to="/cart">Your cart</Link><ChevronRight size={13} /><span>Checkout</span></div>
        <div className="eyebrow">One last detail</div>
        <h1>Where should we bring it?</h1>
        <p>Just your delivery details. This is a demo checkout; no payment will be collected.</p>
      </div>
      <div className="checkout-layout">
        <form className="form-card" onSubmit={submit} noValidate>
          <h2>Delivery details</h2>
          <p>We'll use these details for your order confirmation.</p>
          <div className="form-grid">
            <CheckoutField label="Full name" error={errors.name} className="full">
              <input id="customer-name" autoComplete="name" value={customer.name} onChange={(event) => update('name', event.target.value)} placeholder="Your name" data-testid="input-name" />
            </CheckoutField>
            <CheckoutField label="Email address" error={errors.email}>
              <input id="customer-email" type="email" autoComplete="email" value={customer.email} onChange={(event) => update('email', event.target.value)} placeholder="you@example.com" data-testid="input-email" />
            </CheckoutField>
            <CheckoutField label="Mobile number" error={errors.mobile}>
              <input id="customer-mobile" type="tel" autoComplete="tel" value={customer.mobile} onChange={(event) => update('mobile', event.target.value)} placeholder="10-digit mobile number" data-testid="input-mobile" />
            </CheckoutField>
            <CheckoutField label="Delivery address" error={errors.address} className="full">
              <textarea id="customer-address" autoComplete="street-address" value={customer.address} onChange={(event) => update('address', event.target.value)} placeholder="Room / house, street, area, city and PIN code" data-testid="input-address" />
            </CheckoutField>
          </div>
          <button className="button" type="submit" style={{ width: '100%', marginTop: 22 }} data-testid="button-place-order">Place demo order <ArrowRight size={16} /></button>
          <div style={{ textAlign: 'center', marginTop: 11, color: '#87928b', fontSize: 11 }}>Your cart will clear after confirmation.</div>
        </form>
        <aside className="summary-card">
          <h2>In your order</h2>
          <div>
            {lines.map(({ product, quantity }) => (
              <div className="checkout-summary-item" key={product.id}>
                <img src={product.image} alt="" />
                <div style={{ flex: 1 }}><strong>{product.name}</strong><small>Qty {quantity}</small></div>
                <strong>{formatRupees(product.price * quantity)}</strong>
              </div>
            ))}
          </div>
          <div className="summary-line" style={{ marginTop: 17 }}><span>Campus delivery</span><span style={{ color: 'hsl(var(--primary))', fontWeight: 700 }}>On us</span></div>
          <div className="summary-total"><span>Total</span><span>{formatRupees(subtotal)}</span></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: '#85918a', fontSize: 11, marginTop: 14 }}><CheckCircle2 size={14} /> Safe, simple demo order</div>
        </aside>
      </div>
    </>
  );
}
