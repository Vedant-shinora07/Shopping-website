import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ChevronRight, Search, X } from 'lucide-react';
import { products } from '../store/catalog';
import { ProductGrid } from '../components/ProductGrid';

export function ProductsPage() {
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const category = params.get('category') ?? 'All';
  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return products.filter((product) => {
      const matchesCategory = category === 'All' || product.category === category;
      const matchesQuery = !normalized || product.name.toLowerCase().includes(normalized);
      return matchesCategory && matchesQuery;
    });
  }, [query, category]);

  return (
    <>
      <div className="page-title">
        <div className="breadcrumb"><Link to="/">Home</Link><ChevronRight size={13} /><span>Products</span></div>
        <div className="eyebrow">The campus essentials shelf</div>
        <h1>Find your next favourite.</h1>
        <p>Useful things for class, your desk and everything between.</p>
      </div>
      <div className="catalog-toolbar">
        <label className="searchbox">
          <Search size={18} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search products by name"
            aria-label="Search products by name"
            data-testid="input-product-search"
          />
          {query && (
            <button onClick={() => setQuery('')} aria-label="Clear search" style={{ background: 'none', border: 0, color: '#77817b', display: 'grid' }}>
              <X size={16} />
            </button>
          )}
        </label>
        <select
          className="filter-select"
          value={category}
          onChange={(event) => setParams(event.target.value === 'All' ? {} : { category: event.target.value })}
          aria-label="Filter by category"
          data-testid="select-category"
        >
          <option value="All">All categories</option>
          <option value="Electronics">Electronics</option>
          <option value="Furniture">Furniture</option>
          <option value="Stationery">Stationery</option>
        </select>
        <span style={{ color: '#8a948d', fontSize: 12 }}>{filtered.length} {filtered.length === 1 ? 'item' : 'items'}</span>
      </div>
      <ProductGrid items={filtered} />
    </>
  );
}
