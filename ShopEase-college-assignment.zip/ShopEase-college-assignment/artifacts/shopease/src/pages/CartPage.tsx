import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, ShoppingCart } from 'lucide-react';
import { products } from '../store/catalog';
import { CartItem } from '../components/CartItem';
import { OrderSummary } from '../components/OrderSummary';
import { useStore } from '../store/StoreContext';

export function CartPage() {
  const { cart } = useStore();
  const lines = useMemo(() => cart.map((line) => ({
    ...line,
    product: products.find((product) => product.id === line.productId)!,
  })).filter((line) => line.product), [cart]);
  const subtotal = useMemo(() => lines.reduce((sum, line) => sum + line.product.price * line.quantity, 0), [lines]);

  if (!lines.length) {
    return (
      <>
        <div className="page-title"><div className="eyebrow">Your bag</div><h1>Your cart</h1><p>A little room for your next study-day upgrade.</p></div>
        <div className="empty-state" style={{ margin: '15px 0 75px' }}>
          <div className="empty-icon"><ShoppingCart size={27} /></div>
          <h2>Nothing in your cart just yet</h2>
          <p>Take a look around and find a few things that make campus life easier.</p>
          <Link to="/products" className="button">Browse the shop <ArrowRight size={16} /></Link>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="page-title">
        <div className="eyebrow">Your bag</div>
        <h1>Your cart</h1>
        <p>{cart.reduce((sum, item) => sum + item.quantity, 0)} thoughtful pick{cart.length === 1 ? '' : 's'} for your day.</p>
      </div>
      <div className="cart-layout">
        <div className="cart-list">
          {lines.map(({ product, quantity }) => <CartItem key={product.id} product={product} quantity={quantity} />)}
          <Link to="/products" className="text-link" style={{ marginTop: 8 }}><ArrowLeft size={15} /> Keep browsing</Link>
        </div>
        <OrderSummary
          subtotal={subtotal}
          itemCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
          cta={<Link to="/checkout" className="button" data-testid="button-checkout">Continue to checkout <ArrowRight size={16} /></Link>}
        />
      </div>
    </>
  );
}
