import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Check, CheckCircle2, ChevronRight, ShoppingBag, ShoppingCart } from 'lucide-react';
import { formatRupees, products } from '../store/catalog';
import { useStore } from '../store/StoreContext';

export function ProductPage() {
  const { id } = useParams();
  const product = products.find((item) => item.id === id);
  const { addToCart } = useStore();
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <div className="not-found">
        <div>
          <div className="empty-icon"><ShoppingBag size={25} /></div>
          <h1>That item isn't here.</h1>
          <p style={{ color: '#7b8780' }}>It may have moved off the shelf.</p>
          <Link to="/products" className="button">Back to products</Link>
        </div>
      </div>
    );
  }

  const handleAdd = () => {
    addToCart(product.id);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1800);
  };

  return (
    <>
      <div className="page-title">
        <div className="breadcrumb"><Link to="/">Home</Link><ChevronRight size={13} /><Link to="/products">Products</Link><ChevronRight size={13} /><span>{product.name}</span></div>
      </div>
      <section className="detail-layout">
        <div className="detail-art" style={{ background: product.color }}>
          <img src={product.image} alt={product.name} data-testid={`img-detail-${product.id}`} />
        </div>
        <div className="detail-copy">
          <div className="eyebrow">{product.category}</div>
          <h1>{product.name}</h1>
          <div className="price">{formatRupees(product.price)}</div>
          <p>{product.description}</p>
          <div className="stock-note"><CheckCircle2 size={17} /> In stock and ready for campus</div>
          <div className="detail-actions">
            <button className="button" onClick={handleAdd} disabled={product.stock < 1} data-testid="button-detail-add">
              {added ? <><Check size={17} /> Added to your cart</> : <><ShoppingCart size={17} /> Add to cart</>}
            </button>
            <Link to="/products" className="button secondary"><ArrowLeft size={16} /> Back to shop</Link>
          </div>
          <div className="notice" aria-live="polite">{added ? `${product.name} is in your cart.` : ''}</div>
        </div>
      </section>
    </>
  );
}
