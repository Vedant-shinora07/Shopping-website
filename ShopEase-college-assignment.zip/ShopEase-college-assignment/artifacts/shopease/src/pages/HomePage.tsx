import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Armchair, ArrowRight, ChevronRight, Laptop, PenLine, Truck } from 'lucide-react';
import { products } from '../store/catalog';
import { ProductGrid } from '../components/ProductGrid';

export function HomePage() {
  const navigate = useNavigate();
  const featured = useMemo(() => products.slice(0, 4), []);

  return (
    <>
      <section className="hero" aria-label="Welcome to ShopEase">
        <div className="hero-copy">
          <div className="eyebrow">Your campus, a little more sorted</div>
          <h1>Make room for <span>better</span> study days.</h1>
          <p>From the first note of the semester to the final project push, find the everyday essentials that make campus life easier.</p>
          <div className="hero-actions">
            <Link to="/products" className="button" data-testid="button-shop-products">Shop all essentials <ArrowRight size={16} /></Link>
            <span style={{ color: '#78857e', fontSize: 12 }}>Simple picks. Fair prices.</span>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="desk-scene">
            <div className="scene-disc" /><div className="scene-desk" /><div className="scene-laptop" /><div className="scene-cup" /><div className="scene-plant" />
            <div className="floating-note">The good kind of prep<span>Ready for your next class</span></div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <div><div className="eyebrow">A good place to start</div><h2>Shop by what you need</h2></div>
          <Link to="/products" className="text-link">See everything <ArrowRight size={15} /></Link>
        </div>
        <div className="category-row">
          <button className="category-tile" onClick={() => navigate('/products?category=Electronics')} data-testid="button-category-electronics">
            <div><strong>Electronics</strong><small>Smart tools for getting things done</small></div><span className="category-symbol"><Laptop size={25} /></span>
          </button>
          <button className="category-tile" onClick={() => navigate('/products?category=Furniture')} data-testid="button-category-furniture">
            <div><strong>Furniture</strong><small>Make your corner work for you</small></div><span className="category-symbol"><Armchair size={25} /></span>
          </button>
          <button className="category-tile" onClick={() => navigate('/products?category=Stationery')} data-testid="button-category-stationery">
            <div><strong>Stationery</strong><small>Small things, very big ideas</small></div><span className="category-symbol"><PenLine size={24} /></span>
          </button>
        </div>
      </section>

      <section className="section" style={{ paddingTop: 65 }}>
        <div className="section-heading">
          <div><div className="eyebrow">Student favourites</div><h2>Ready for the desk</h2></div>
          <Link to="/products" className="text-link">Browse the collection <ArrowRight size={15} /></Link>
        </div>
        <ProductGrid items={featured} />
      </section>

      <section style={{ marginTop: 74, borderRadius: 22, background: '#e9efe7', padding: '27px 30px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 15 }}>
          <span className="category-symbol"><Truck size={23} /></span>
          <div><strong style={{ fontFamily: 'var(--app-font-display)' }}>Made for campus life</strong><div style={{ fontSize: 13, color: '#78857e', marginTop: 4 }}>Straightforward shopping, easy delivery details.</div></div>
        </div>
        <Link to="/products" className="text-link">Find your essentials <ChevronRight size={16} /></Link>
      </section>
    </>
  );
}
